Lu Perfumes e Presentes - Site estático (HTML/CSS/JS)

Como testar localmente:
1) Descompacte o arquivo e abra o arquivo `index.html` no seu navegador.
2) Clique em 'Entrar no Catálogo' para ver os produtos. O botão 'Comprar pelo WhatsApp' abre o WhatsApp no número +55 65 99206-0457.

Como publicar grátis (GitHub Pages):
1) Crie um repositório no GitHub (por exemplo: lu-perfumes).
2) Faça upload de todos os arquivos (arraste e solte a pasta descompactada).
3) No repositório do GitHub, vá em Settings -> Pages -> Branch: selecione 'main' (ou 'master') e folder '/ (root)' e clique em Save.
4) O GitHub vai fornecer a URL pública (https://<seu-usuario>.github.io/<nome-do-repositorio>/).
5) Pronto — o site será público e qualquer pessoa poderá ver (sem login).

Quer que eu faça o upload direto pro seu repositório do GitHub agora (se você me autorizar a acessar)?
